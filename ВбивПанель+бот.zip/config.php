<?php

// База данных
const DB_HOST = ''; // Хост базы данных
const DB_USER = ''; // Имя пользователя
const DB_PASS = ''; // Пароль
const DB_NAME = ''; // Название базы данных
?>
